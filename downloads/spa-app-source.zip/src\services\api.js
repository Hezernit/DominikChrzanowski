
import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:3001"
});

export const getEvents = () => API.get("/events");
export const getEvent = (id) => API.get(`/events/${id}`);
export const addEvent = (data) => API.post("/events", data);
