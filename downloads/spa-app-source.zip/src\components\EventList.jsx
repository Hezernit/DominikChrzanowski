
import { useEffect, useState } from "react";
import { getEvents } from "../services/api";
import { Link } from "react-router-dom";

export default function EventList() {
  const [events, setEvents] = useState([]);

  useEffect(() => {
    getEvents()
      .then(res => setEvents(res.data))
      .catch(() => alert("Błąd pobierania danych"));
  }, []);

  if (!events.length) return <p>Brak danych</p>;

  return (
    <div>
      <h1>Lista wydarzeń</h1>
      <Link to="/add">Dodaj</Link>
      <ul>
        {events.map(e => (
          <li key={e.id}>
            <Link to={`/event/${e.id}`}>{e.name}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
