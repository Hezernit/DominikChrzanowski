
import { useState } from "react";
import { addEvent } from "../services/api";
import { useNavigate } from "react-router-dom";

export default function EventForm() {
  const [form, setForm] = useState({
    name: "",
    description: "",
    date: ""
  });

  const navigate = useNavigate();

  const validate = () => {
    if (!form.name || form.name.length < 3) return "Nazwa min 3 znaki";
    if (!form.description) return "Opis wymagany";
    if (!/\d{4}-\d{2}-\d{2}/.test(form.date)) return "Zła data";
    return null;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const error = validate();
    if (error) return alert(error);

    addEvent(form).then(() => navigate("/"));
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        placeholder="Nazwa"
        onChange={e => setForm({ ...form, name: e.target.value })}
      />
      <input
        placeholder="Opis"
        onChange={e => setForm({ ...form, description: e.target.value })}
      />
      <input
        type="date"
        onChange={e => setForm({ ...form, date: e.target.value })}
      />
      <button>Dodaj</button>
    </form>
  );
}
