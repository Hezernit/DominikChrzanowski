
import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { getEvent } from "../services/api";

export default function EventDetails() {
  const { id } = useParams();
  const [event, setEvent] = useState(null);

  useEffect(() => {
    getEvent(id)
      .then(res => setEvent(res.data))
      .catch(() => alert("Błąd"));
  }, [id]);

  if (!event) return <p>Ładowanie...</p>;

  return (
    <div>
      <h2>{event.name}</h2>
      <p>{event.description}</p>
      <p>{event.date}</p>
    </div>
  );
}
