
import { BrowserRouter, Routes, Route } from "react-router-dom";
import EventList from "./components/EventList";
import EventDetails from "./components/EventDetails";
import EventForm from "./components/EventForm";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<EventList />} />
        <Route path="/event/:id" element={<EventDetails />} />
        <Route path="/add" element={<EventForm />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
